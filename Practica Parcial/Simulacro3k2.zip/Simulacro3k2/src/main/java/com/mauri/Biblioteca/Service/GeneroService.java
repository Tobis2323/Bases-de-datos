package com.mauri.Biblioteca.Service;

public class GeneroService {
}
