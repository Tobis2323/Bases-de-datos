package com.mauri.Biblioteca.Models;

public enum Clasificacion {
    EVERYONE,
    EVERYONE_10_PLUS,
    TEEN,
    MATURE,
    ADULTS_ONLY,
    RATING_PENDING
}
